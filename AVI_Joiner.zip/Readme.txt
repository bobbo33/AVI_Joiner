AVI Joiner
v0.2 2010-01-24
Copyright 2010 Bob Menke

Description:
Allows user to select and organize a list of AVI files.
Runs MEncoder to join these AVI files into one file.

The files in this package:
AVI_Joiner.exe   - the main executable
AVI_Joiner.ahk   - source code (written in Autohotkey:  www.autohotkey.com)
license.txt      - a copy of the GNU General Public License (GNU GPL)
Readme.txt       - this document
mencoder.exe     - video encoder

MEncoder is part of the MPlayer project, and is distributed under the GNU GPLv3:
Name:       MEncoder.exe
Version:    1.0rc1-3.4.2
Homepage:   http://www.mplayerhq.hu
License:    GNU General Public License
MEncoder source code is maintained and distributed through the MPlayer website.

The latest version of this program can always be found at:
http://productivegeek.com/forums/topic/lets-do-a-simple-ahk-project-together-avi-joiner
